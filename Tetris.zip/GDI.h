#ifndef _GDI_H_
#define _GDI_H_
#include <windows.h>

class CGDI 
{
private:
	//memory dc
	HDC hdcMem;

	//new bitmap
	HBITMAP hbmNew;

	//old bitmap
	HBITMAP hbmOld;

	//width and height
	int nWidth;
	int nHeight;

public:
	//constructor
	CGDI();

	//loads bitmap from a file
	void Load(HDC hdcCompatible,LPCTSTR lpszFilename);

	//creates a blank bitmap
	void CreateBlank(HDC hdcCompatible, int width, int height);

	//destroys bitmap and dc
	void Destroy();

	//converts to HDC
	operator HDC();

	//return width
	int GetWidth();

	//return height
	int GetHeight();

	//destructor
	~CGDI();
};

#endif 
