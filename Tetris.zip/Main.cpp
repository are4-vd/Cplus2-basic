//aplikasi membuat game tetris

////////////// INCLUDES ///////////////////////

//include lib. windows
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>


//include warp up fungsi2 directdraw
#include "directx.h"

////////////// DEFINES ///////////////////////

//no MFC
#define WIN32_LEAN_AND_MEAN

//panjang dan lebar peta permainan (satuan : kotak/elemen)
#define pjg_map 20
#define lebar_map 10
#define waktu_restart 3	// Pewaktu sebelum restart

//panjang dan lebar 1 kotak/elemen (satuan : pixel)
#define pjg_elemen	 16
#define lebar_elemen 16

//posisi X & Y medan permainan (satuan : pixel)
#define posisiX_medan 200
#define posisiY_medan 50

////////////// MACROS ///////////////////////

//macro untuk input keyboard
#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code)&0x8000)?1:0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code)&0x8000)?0:1)
#define KEYTAP(vk_code) ( !(oldkey[vk_code]&0x8000) && (newkey[vk_code]&0x8000) )

// Link dengan library yang diperlukan,
// Direct Draw dan Direct X GUID
#pragma comment(lib, "ddraw.lib")
#pragma comment(lib, "dxguid.lib")

//enumerasi gambar2 yg digunakan dalam permainan
typedef enum
{
	GBR_KOTAK,
	GBR_BKGR,
	GBR_BINGKAI_KIRIATAS,
	GBR_BINGKAI_KANANATAS,
	GBR_BINGKAI_KIRIBAWAH,
	GBR_BINGKAI_KANANBAWAH,
	GBR_BINGKAI_ATAS,
	GBR_BINGKAI_BAWAH,
	GBR_BINGKAI_KIRI,
	GBR_BINGKAI_KANAN

} ENUMERASI_GAMBAR;

//struct 1 kotak/elemen
struct _kotak
{
	int x;
	int y;
};

//struct 1 block/bentuk
struct group
{
	int 	x,y;
	int		initpos;
	_kotak	kotak[4];
};

//init peta permainan
void init_map();

//buat template block
void create_block();

//rotate block aktif
void rotate();

//cek input keyboard
void cek_input();

//load gambar
void load_art();

//gambar 1 elemen
void gambar_elemen( ENUMERASI_GAMBAR gbr, int posisiX, int posisiY );

//gambar game area
void gambar_medantempur( int posisiX, int posisiY, int panjang, int lebar,bool draw_map);

//gambar 1 block
void gambar_block(group& block,int posisiX, int posisiY);

//hapus 1 baris yg terbentuk
void hapus_baris( int t );

//deteksi tumbukan
bool coll_check(group& block,bool write);

//cek apakah telah terbentuk 1 baris ?
void cek_row();


/////////////////// GLOBALS ///////////////////////

////////////////////////
//DirectDraw Globals  //
////////////////////////
HWND					hWnd;				//handle ke window
LPDIRECTDRAW7	        lpdd		= NULL;	//directdraw
LPDIRECTDRAWSURFACE7	lpddsMain	= NULL;	//primary surface
LPDIRECTDRAWSURFACE7	lpddsBack	= NULL;	//back buffer
LPDIRECTDRAWSURFACE7	lpddsArt    = NULL; //semua art yg dibutuhkan game

//Game Globals
char	map[pjg_map][lebar_map];	//game area
bool	win=false,loose=false;		//win,loose condition
bool	flash_down = false;			//flag block meluncur ke bawah
int		active = 0,next = 0;		//index active block & index next block
long	waktu_gameover  = 0;

char oldkey[256];	//keyboard keys holder
char newkey[256];	//keyboard keys holder

DWORD	dwLastTick =0;	//var. delay jatuhnya block

group	block_active;	//active block
group   block[7];		//template block
		// 0 - I
		// 1 - Z
		// 2 - S
		// 3 - L
		// 4 - J
		// 5 - O
		// 6 - T


////////////// FUNCTION ///////////////////////

LRESULT CALLBACK WinProc(HWND hwnd, UINT msg,WPARAM wparam, LPARAM lparam)
{ //begin WinProc

  PAINTSTRUCT	ps;	//digunakan di WM_PAINT
  HDC			hdc;  //digunakan di WM_PAINT

    switch(msg)         // Switch berita yang masuk!
    {
    case WM_CREATE :
    {
        // lakukan proses inisialisasi di sini
        return 0;
    } break;
    case WM_PAINT :
    {
        hdc = BeginPaint(hwnd,&ps);
        // lakukan proses penggambaran di sini
        EndPaint(hwnd,&ps);
        return 0;
    } break;
    case WM_DESTROY :
    {
        PostQuitMessage(0);
        return 0;
    } break;
    default : break;
    } //end switch

    return (DefWindowProc(hwnd,msg,wparam,lparam));
} // end WinProc


void Game_Running()
{
	//cek tabrakan
	if (coll_check(block_active,true))
	{
	    //apakah ada 1 baris yg terbentuk ?
		cek_row();

		active = next;
		next = GetTickCount() % 7;

		//block_active = block[active]
		memcpy(&block_active,&block[active],sizeof(group));

		//posisi awal = tengah atas
		block_active.x = lebar_map/2 - 1;
		block_active.y = block[active].initpos;

		//bila sudah terjadi collision maka game over
		if (coll_check(block_active,false))
		{
			loose = true;
			waktu_gameover = GetTickCount();
		}
		flash_down = false;

	} else
		//jika tombol bawah ditekan ... block akan langsung meluncur ke bawah
		if (flash_down) block_active.y += 1; else
			//jika tidak .. siap2 terima input keyboard
			cek_input();


	//delay waktu jatuh block selama 1 detik
	DWORD dwCurTick = GetTickCount();
	if (dwCurTick-dwLastTick >= 1000)
	{
		block_active.y += 1;
		dwLastTick = dwCurTick;
	}
}

void Game_Over()
{
	char tempbuff[255];

	if( GetTickCount()-waktu_gameover < (waktu_restart*1000) )
	{
		Draw_Text_GDI("GAME BERAKHIR, ANDA KALAH !", 200, 200,RGB(255,0,255), lpddsBack);
		sprintf( tempbuff, "GAME RESTART DALAM %d DETIK", waktu_restart-((GetTickCount()-waktu_gameover)/1000) );
		Draw_Text_GDI(tempbuff, 200, 220,RGB(255,0,0), lpddsBack);
	}
	else
	{
		init_map();
		loose=false;
	}
}

int Game_Init()
{
	//set up ddraw
	lpdd=LPDD_Create(hWnd,DDSCL_FULLSCREEN | DDSCL_EXCLUSIVE | DDSCL_ALLOWREBOOT);
	lpdd->SetDisplayMode(640,480,16,0,0);

	//set up primary surface
    lpddsMain=LPDDS_CreatePrimary(lpdd,1);

	//set up back buffer
    lpddsBack=LPDDS_GetSecondary(lpddsMain);

	//baca file gambar
	load_art();

	//clear out main + back buffer
	DDBLTFX ddbltfx;
	DDBLTFX_ColorFill(&ddbltfx,0);
	lpddsMain->Blt(NULL,NULL,NULL,DDBLT_WAIT | DDBLT_COLORFILL,&ddbltfx);
	lpddsBack->Blt(NULL,NULL,NULL,DDBLT_WAIT | DDBLT_COLORFILL,&ddbltfx);

	//init map
	init_map();
	//buat template block
	create_block();
	//block aktif random 0 - 6
	active = GetTickCount() % 7;
	//next block random 0 - 6
	next = GetTickCount() % 7;

	//copy block aktif dari template block
	memcpy(&block_active,&block[active],sizeof(group));

	//tengahkan posisi block aktif
	block_active.x = lebar_map/2 - 1;
	block_active.y = block[active].initpos;

	return 0;
}

int Game_Main()
{

	//bersihkan Back buffer
	DDBLTFX ddbltfx;
	DDBLTFX_ColorFill(&ddbltfx,0);
	lpddsBack->Blt(NULL,NULL,NULL,DDBLT_WAIT | DDBLT_COLORFILL,&ddbltfx);

	//gambar game area
	gambar_medantempur(posisiX_medan,posisiY_medan,lebar_map,pjg_map,true);

	//gambar panel preview next block
	gambar_medantempur(posisiX_medan+(lebar_map+1) * lebar_elemen,posisiY_medan,5,5,false);

	//gambar next block
	gambar_block(block[next],(lebar_map+3)*lebar_elemen+posisiX_medan,(block[next].initpos+1)*lebar_elemen+posisiY_medan);

	//gambar block yg sedang aktif
	gambar_block(block_active,block_active.x*lebar_elemen+posisiX_medan,block_active.y*lebar_elemen+posisiY_medan);

	if( !loose )
		Game_Running();
	else
		Game_Over();

	//flip main buffer <> back buffer
	lpddsMain->Flip(NULL,DDFLIP_WAIT);
	return 0;
}

int Game_Exit()
{
	//bersihkan surface untuk art
	LPDDS_Release(&lpddsArt);

	//bersihkan back buffer
	LPDDS_Release(&lpddsBack);

	//bersihkan main buffer
	LPDDS_Release(&lpddsMain);

    //bersihkan ddraw
	LPDD_Release(&lpdd);
	return 0;
}

////////////// WINMAIN ///////////////////////
int WINAPI WinMain(HINSTANCE hInstance,
			   HINSTANCE hprevInstance,
			   LPSTR lpcmdline,int ncmdshow)
{
    //start WinMain

	WNDCLASSEX windowcx; 	//kelas window kita
	MSG	msg;				// Berita untuk perulangan utama

	windowcx.cbSize 	= sizeof(WNDCLASSEX);
	windowcx.style	= CS_VREDRAW | CS_HREDRAW |
	  CS_OWNDC   | CS_DBLCLKS;
	windowcx.lpfnWndProc = WinProc;
	windowcx.cbClsExtra	= 0;
	windowcx.cbWndExtra	= 0;
	windowcx.hInstance	= hInstance;
	windowcx.hIcon	= LoadIcon(NULL,IDI_APPLICATION);
	windowcx.hCursor	= LoadCursor(NULL,IDC_ARROW);
	windowcx.hbrBackground =
	(HBRUSH)GetStockObject(BLACK_BRUSH);
	windowcx.lpszMenuName  = NULL;
	windowcx.lpszClassName = "KelasWindow1";
	windowcx.hIconSm	 = LoadIcon(NULL,IDI_APPLICATION);


	//Register kelas Window kita
	if (!RegisterClassEx(&windowcx)) return 0;

	//buat window dari kelas window di atas
	if (!(hWnd = CreateWindowEx(
			NULL, 					//dwExStyle
 			"KelasWindow1", 		//lpClassName
	   		"Window 1 Buatan Saya",	//lpWindowName
			WS_POPUP  | WS_VISIBLE, //dwStyle
 			10,10, 					//x,y
			400,200,		  		//nWidth,nHeight
			NULL,					//hWndParent
			NULL,					//hMenu
			hInstance,				//hInstance
			NULL)))					//lpParam
	return 0;


	//Perulangan Utama
	Game_Init();	  // inisialisasi game

	while (TRUE)
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{
			if (msg.message == WM_QUIT) break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		Game_Main();
	}//akhir Perulangan Utama

	Game_Exit();      // fungsi akhir game

	return (msg.wParam); //kembali ke OS(Windows).
} //end WinMain


void create_block()
{

  // I     |
  //       |
  //       |
  //       |
  block[0].x = 1;
  block[0].y = 0;
  block[0].initpos = 1;

  block[0].kotak[0].x = 0;
  block[0].kotak[0].y = 0;

  block[0].kotak[1].x = 0;
  block[0].kotak[1].y = -1;

  block[0].kotak[2].x = 0;
  block[0].kotak[2].y = 1;

  block[0].kotak[3].x = 0;
  block[0].kotak[3].y = 2;

  // S    ==
  //     ==
  block[1].x = 1;
  block[1].y = 0;
  block[1].initpos = 0;

  block[1].kotak[0].x = 0;
  block[1].kotak[0].y = 0;

  block[1].kotak[1].x = -1;
  block[1].kotak[1].y = 0;

  block[1].kotak[2].x = 0;
  block[1].kotak[2].y = 1;

  block[1].kotak[3].x = 1;
  block[1].kotak[3].y = 1;


  // Z   ==
  //      ==
  block[2].x = 1;
  block[2].y = 0;
  block[2].initpos = 0;

  block[2].kotak[0].x = 0;
  block[2].kotak[0].y = 0;

  block[2].kotak[1].x = 1;
  block[2].kotak[1].y = 0;

  block[2].kotak[2].x = 0;
  block[2].kotak[2].y = 1;

  block[2].kotak[3].x = -1;
  block[2].kotak[3].y = 1;

  // J    =
  //      =
  //     ==
  block[3].x = 1;
  block[3].y = 0;
  block[3].initpos = 2;

  block[3].kotak[0].x = 0;
  block[3].kotak[0].y = 0;

  block[3].kotak[1].x = 1;
  block[3].kotak[1].y = 0;

  block[3].kotak[2].x = 0;
  block[3].kotak[2].y = -1;

  block[3].kotak[3].x = 0;
  block[3].kotak[3].y = -2;

  // L	  =
  //      =
  //      ==
  block[4].x = 1;
  block[4].y = 0;
  block[4].initpos = 2;

  block[4].kotak[0].x = 0;
  block[4].kotak[0].y = 0;

  block[4].kotak[1].x = -1;
  block[4].kotak[1].y = 0;

  block[4].kotak[2].x = 0;
  block[4].kotak[2].y = -1;

  block[4].kotak[3].x = 0;
  block[4].kotak[3].y = -2;

  // O     ==
  //       ==
  block[5].x = 1;
  block[5].y = 0;
  block[5].initpos = 0;

  block[5].kotak[0].x = 0;
  block[5].kotak[0].y = 0;

  block[5].kotak[1].x = 0;
  block[5].kotak[1].y = 1;

  block[5].kotak[2].x = -1;
  block[5].kotak[2].y = 0;

  block[5].kotak[3].x = -1;
  block[5].kotak[3].y = 1;


  // T   =
  //    ===
  block[6].x = 1;
  block[6].y = 0;
  block[6].initpos = 1;

  block[6].kotak[0].x = 0;
  block[6].kotak[0].y = 0;

  block[6].kotak[1].x = 0;
  block[6].kotak[1].y = 1;

  block[6].kotak[2].x = -1;
  block[6].kotak[2].y = 0;

  block[6].kotak[3].x = 1;
  block[6].kotak[3].y = 0;

}

void init_map()
{
    //inisialisasi peta permainan

	memset( &map[0][0], '0', lebar_map*pjg_map*sizeof(char) );
}

void rotate()
{
	group block_temp;


	//block temp = block active
	memcpy(&block_temp,&block_active,sizeof(group));

	//rotate block temp
    for (int i=0;i<4;i++)
    {
        block_temp.kotak[i].x = block_temp.kotak[i].x + block_temp.kotak[i].y;
        block_temp.kotak[i].y = block_temp.kotak[i].x - block_temp.kotak[i].y;
        block_temp.kotak[i].x = -(block_temp.kotak[i].x - block_temp.kotak[i].y);
	}

	//jika hasil rotate tidak tabrakan lakukan rotate sesungguhnya
	if (!coll_check(block_temp,false))
    for (i=0;i<4;i++)
    {
        block_active.kotak[i].x = block_active.kotak[i].x + block_active.kotak[i].y;
        block_active.kotak[i].y = block_active.kotak[i].x - block_active.kotak[i].y;
        block_active.kotak[i].x = -(block_active.kotak[i].x - block_active.kotak[i].y);
	}

}

void cek_input()
{
	bool inside = true;

	//simpan kondisi buffer keyboard saat ini
	GetKeyboardState( (unsigned char*)newkey );

    if KEYTAP(VK_LEFT)
	{
		//cek apakah block akan tetap berada di dalam game area bila digerakan ke kiri ?
	    for (int i=0;i<4;i++)
			 if (((block_active.x+block_active.kotak[i].x) <= 0) ||
				 (map[block_active.y+block_active.kotak[i].y][block_active.x+block_active.kotak[i].x-1] == 'x'))
				 inside = false;

		//bila ya, geser block ke kiri
		if (inside) block_active.x -=1;
	}
	if KEYTAP(VK_RIGHT)
	{
		//cek apakah block akan tetap berada di dalam game area bila digerakan ke kanan ?
		for (int i=0;i<4;i++)
			 if (((block_active.x+block_active.kotak[i].x) >= lebar_map-1 ) ||
				 (map[block_active.y+block_active.kotak[i].y][block_active.x+block_active.kotak[i].x+1] == 'x'))
				 inside = false;

		//bila ya, geser block ke kanan
		if (inside) block_active.x +=1;
	}


	if KEYTAP(VK_UP)
	{
		//bila block bukan bentuk kotak, rotasikan !
		if (active != 5) rotate();
	}

	//bila tombol bawah ditekan ... balok akan meluncur turun
	if KEYTAP(VK_DOWN) {flash_down = true;}

	//bila ESC ditekan program keluar
	if KEYDOWN(VK_ESCAPE) SendMessage(hWnd,WM_CLOSE,0,0);

	//copy buffer keyboard di newkey ke oldkey
	memcpy(oldkey,newkey,256*sizeof(char));
}

void load_art()
{
	DDSURFACEDESC2 ddsd;
	DDSD_Clear(&ddsd);

	lpddsArt = LPDDS_LoadFromFile( lpdd, "art.bmp" );

	lpddsArt->GetSurfaceDesc(&ddsd);
	LPDDS_SetSrcColorKey(lpddsArt,ConvertColorRef(RGB(255,0,255),&ddsd.ddpfPixelFormat));
}

void gambar_elemen( ENUMERASI_GAMBAR gbr, int posisiX, int posisiY )
{
	RECT dest_rect,source_rect;
	int idx;

	idx = gbr;

	//source rectangle
    source_rect.left = idx * lebar_elemen;
    source_rect.top =  0;
    source_rect.right = ((idx+1) * lebar_elemen);
    source_rect.bottom = pjg_elemen;

	//dest rectangle
    dest_rect.left = posisiX;
    dest_rect.top =  posisiY;
    dest_rect.right = posisiX + lebar_elemen;
    dest_rect.bottom = posisiY + pjg_elemen;

	lpddsBack->Blt(&dest_rect,lpddsArt,&source_rect,(DDBLT_WAIT | DDBLT_KEYSRC),NULL);
}

void gambar_block(group& block,int posisiX, int posisiY)
{
    for(int i =0;i<4;i++)
		gambar_elemen(GBR_KOTAK,posisiX+(block.kotak[i].x+1/*bingkai*/)*pjg_elemen,
		posisiY+(block.kotak[i].y+1/*bingkai*/)*pjg_elemen);
}

void gambar_medantempur( int posisiX, int posisiY, int panjang, int lebar,bool draw_map)
{
	int i,j;

	// gambar background medan tempur + pinggiran bingkai
	for(i=0;i<panjang+2;++i)
		for(j=0;j<lebar+2;++j)
		{
			if( i==0 && j%(lebar+1)!=0 )
				gambar_elemen( GBR_BINGKAI_KIRI, posisiX+i*pjg_elemen, posisiY+j*lebar_elemen );
			else if(i==panjang+1 && j%(lebar+1)!=0 )
				gambar_elemen( GBR_BINGKAI_KANAN, posisiX+i*pjg_elemen, posisiY+j*lebar_elemen );
			else if(j==0 && i%(panjang+1)!=0 )
				gambar_elemen( GBR_BINGKAI_ATAS, posisiX+i*pjg_elemen, posisiY+j*lebar_elemen );
			else if(j==lebar+1  && i%(panjang+1)!=0 )
				gambar_elemen( GBR_BINGKAI_BAWAH, posisiX+i*pjg_elemen, posisiY+j*lebar_elemen );
			else if(i>0 && i<panjang+1 && j>0 && j<lebar+1)
				{
					gambar_elemen( GBR_BKGR, posisiX+i*pjg_elemen, posisiY+j*lebar_elemen );
					if ((draw_map)&&(map[j-1][i-1] == 'x'))
					gambar_elemen(GBR_KOTAK, posisiX+i*pjg_elemen, posisiY+j*lebar_elemen );
				}
		}

	// gambar pojok bingkai medan tempur
	gambar_elemen( GBR_BINGKAI_KIRIATAS, posisiX, posisiY );
	gambar_elemen( GBR_BINGKAI_KANANATAS, posisiX+(panjang+1)*pjg_elemen, posisiY );
	gambar_elemen( GBR_BINGKAI_KIRIBAWAH, posisiX, posisiY+(lebar+1)*lebar_elemen );
	gambar_elemen( GBR_BINGKAI_KANANBAWAH, posisiX+(panjang+1)*pjg_elemen, posisiY+(lebar+1)*lebar_elemen );
}


bool coll_check(group& block,bool write)
{
    int i=0;
    int x,y,k,l;
    bool coll = false;

    while ((i < 4) && (!coll))
    {
       x = block.x  + block.kotak[i].x;
       y = block.y  + block.kotak[i].y;

       if ( (x < 0) || (x >= lebar_map) || (y<0) || (map[y+1][x] == 'x') || (y >= pjg_map-1) )
       {
           //collide
           coll = true;
           for (int j=0;j<4;j++)
           {
               k = block.x  + block.kotak[j].x;
               l = block.y  + block.kotak[j].y;

			   if ((write) && (k >= 0) && (k < lebar_map) && (l >= 0) && (l < pjg_map))
			   map[l][k] = 'x';
           }
       }
       i++;

	 }
     return(coll);
}

void cek_row()
{
	int  y;
	bool tandai_hapus[pjg_map];

    for(y=pjg_map-1;y>=0;y--)
    {
		tandai_hapus[y]=true;
		for(int x=0;x<lebar_map;x++)
		{
			//cek row, is it a line ?
			if (map[y][x] == '0')
			{
				tandai_hapus[y]=false;
				break;
			}
		}
	}

	for(y=0;y<pjg_map;++y)
		if(tandai_hapus[y])
			hapus_baris(y);
}

void hapus_baris( int t )
{
	int i, j;

	if( t<=0 )
		return;

	// Kopi isi baris - baris diatas baris yg hendak dihapus
	for( i=t; i>0; --i)
		for(int j=0; j<lebar_map; j++)
			map[i][j]=map[i-1][j];

	// Isi baris paling atas dengan baris baru yang kosong
	for( j=0; j<lebar_map; j++)
		map[0][j] = '0';
}